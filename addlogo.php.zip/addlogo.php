<?php 
/*

	Plugin Name: Add Logo
	Description: Add your own WP Logo on admin bar
	Author: Kevin Pichette
	Version: 1.0
	Author URI: http://kevinpichette.com

*/

add_action('wp_before_admin_bar_render', 'no_wp_logo_admin_bar_remove');

function no_wp_logo_admin_bar_remove($wp_admin_bar)
{
	?>
	<style type="text/css">
		#wpadminbar #wp-admin-bar-wp-logo > .ab-item .ab-icon:before { 
			content: url(http://localhost:8888/kp-mine16/wordpress/wp-content/uploads/2016/03/kp.png) !important;
		}

		#wpadminbar #wp-admin-bar-wp-logo > .ab-item {
			pointer-events: none;
			cursor: default;
		}

	</style>
<?php
}

?>